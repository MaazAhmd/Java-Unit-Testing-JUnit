package main.mockitoTesting;

public interface UserRepository {
    String findUserById(int id);
}
